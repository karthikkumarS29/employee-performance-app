package com.EmployeeAprisal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmployeeAprisalApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmployeeAprisalApplication.class, args);
	}

}
