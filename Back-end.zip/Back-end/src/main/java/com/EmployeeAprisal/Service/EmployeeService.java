package com.EmployeeAprisal.Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.EmployeeAprisal.Repo.AppraisalRepository;
import com.EmployeeAprisal.Repo.EmployeeRepository;
import com.EmployeeAprisal.model.Appraisal;
import com.EmployeeAprisal.model.Employee;

@Service
public class EmployeeService {

    @Autowired
    private EmployeeRepository employeeRepository;
    @Autowired
    private AppraisalRepository appraisalRepository;
    
    public List<Employee> getAllEmployee(){
    	return this.employeeRepository.findAll();
    }

    public Map<String, Double> calculatePercentageDeviations() {
        List<Employee> employees = employeeRepository.findAll();
        System.err.println(employees);
        Map<String, Integer> actualPercentageMap = new HashMap<>();

        // Calculate actual percentage distribution
        for (Employee employee : employees) {
            String category = employee.getRating();
            actualPercentageMap.put(category, actualPercentageMap.getOrDefault(category, 0) + 1);
        }
       // System.err.println(actualPercentageMap);
        

        // Calculate deviation from standard
        Map<String, Double> deviations = new HashMap<>();
        List<Appraisal> appraisalList = appraisalRepository.findAll();
        System.err.println(appraisalList);
        for (Appraisal appraisal : appraisalList) {
            String category = appraisal.getCategory();
            int standardPercentage = appraisal.getStandardPercentage();
            int actualCount = actualPercentageMap.getOrDefault(category, 0);
            double actualPercentage = (actualCount / (double) employees.size()) * 100;
            double deviation = actualPercentage - standardPercentage;
            deviations.put(category, deviation);
        }
          System.err.println(deviations);
        return deviations;
    }

    public List<String> suggestRevisions() {
        Map<String, Double> deviations = calculatePercentageDeviations();
        List<String> suggestions = new ArrayList<>();

        for (Map.Entry<String, Double> entry : deviations.entrySet()) {
            if (Math.abs(entry.getValue()) > 10) {
                suggestions.add("Category " + entry.getKey() + " needs revision. Deviation: " + entry.getValue() + "%");
            }
        }

        return suggestions;
    }
}
