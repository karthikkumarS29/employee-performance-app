package com.EmployeeAprisal.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.Data;
@Data
@Entity
public class Employee {
	 @Id
	    private String employeeId;
	    private String employeeName;
	    private String rating;
		
}