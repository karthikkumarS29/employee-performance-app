package com.EmployeeAprisal.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Rating {
    @Id
    private String rating;
    private String category;
	public String getRating() {
		return rating;
	}
	public void setRating(String rating) {
		this.rating = rating;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}

}
