package com.EmployeeAprisal.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

	@Entity
	public class Appraisal {
	    @Id
	    private String category;
	    private int standardPercentage;
	    private int actualPercentage;
		public String getCategory() {
			return category;
		}
		public void setCategory(String category) {
			this.category = category;
		}
		public int getStandardPercentage() {
			return standardPercentage;
		}
		public void setStandardPercentage(int standardPercentage) {
			this.standardPercentage = standardPercentage;
		}
		public int getActualPercentage() {
			return actualPercentage;
		}
		public void setActualPercentage(int actualPercentage) {
			this.actualPercentage = actualPercentage;
		}

	    
	}

