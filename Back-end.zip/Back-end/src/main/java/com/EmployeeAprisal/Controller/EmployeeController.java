package com.EmployeeAprisal.Controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.EmployeeAprisal.Service.EmployeeService;
import com.EmployeeAprisal.model.Employee;
@Controller
@RequestMapping("/Home")
public class EmployeeController {

    @Autowired
    private EmployeeService employeeService;
    
//    @GetMapping("/index")
//    public String home() {
//    	System.err.println("getDeviations controller method");
//        return "index";
//    }
    
    
    @GetMapping("/getAllEmployee")
    @ResponseBody
    public List<Employee> getAllEmployee() {
    	System.err.println("getAllEmployee controller method");
        return this.employeeService.getAllEmployee();
    }

    @GetMapping("/deviations")
    @ResponseBody
    public Map<String, Double> getDeviations() {
    	System.err.println("getDeviations controller method");
        return employeeService.calculatePercentageDeviations();
    }

    @GetMapping("/suggestions")
    @ResponseBody
    public List<String> getSuggestions() {
        return employeeService.suggestRevisions();
    }
}
