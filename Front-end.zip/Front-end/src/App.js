import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { Line } from 'react-chartjs-2';
import 'chart.js/auto';

function App() {
    const [employees, setEmployees] = useState([]);
    const [actualPercentage, setActualPercentage] = useState({});

    useEffect(() => {
        // Fetch employee details
        axios.get('http://localhost:8080/EmployeeAprisal/Home/getAllEmployee')
            .then(response => setEmployees(response.data))
            .catch(error => console.error('Error:', error));

        // Fetch actual percentage
        axios.get('http://localhost:8080/EmployeeAprisal/Home/deviations')
            .then(response => setActualPercentage(response.data))
            .catch(error => console.error('Error:', error));
    }, []);

    // Prepare data for Line Graph
    const chartData = {
        labels: Object.keys(actualPercentage),
        datasets: [
            {
                label: 'Actual Percentage',
                data: Object.values(actualPercentage),
                borderColor: 'rgb(192, 75, 75)',
                backgroundColor: 'rgba(75, 192, 192, 0.2)',
                tension: 0.4, // Smooth curve
            }
        ]
    };

    return (
        <div style={{ margin: '20px' }}>
            <h1>Employee Performance Dashboard</h1>

            {/* Table Section */}
            <h2>Employee Details</h2>
            <table border="1" cellPadding="5" style={{ width: '50%', margin: '20px auto', textAlign: 'center' }}>
                <thead>
                    <tr>
                        <th>Employee ID</th>
                        <th>Employee Name</th>
                        <th>Rating</th>
                    </tr>
                </thead>
                <tbody>
                    {employees.map(emp => (
                        <tr key={emp.id}>
                            <td>{emp.employeeId}</td>
                            <td>{emp.employeeName}</td>
                            <td>{emp.rating}</td>
                        </tr>
                    ))}
                </tbody>
            </table>

            {/* Line Graph Section */}
            <h2>Performance Distribution (Line Graph)</h2>
            <div style={{ width: '50%', margin: '0 auto' }}>
                <Line data={chartData} />
            </div>
        </div>
    );
}

export default App;
